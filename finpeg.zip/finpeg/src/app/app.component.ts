import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  funds: any;
  performanceDetails: boolean = false;

  private _jsonURL = 'assets/funds.json';
  title = 'finpeg';
  
  constructor(private http: HttpClient) {
    this.getJSON().subscribe(data => {
      console.log(data);
      this.funds = data.result.funds;
      console.log(this.funds);
    });
  }
  public getJSON(): Observable<any> {
    return this.http.get(this._jsonURL);
  }
  ngOnInit() {
      }


showPerformanceDetails(){
  this.performanceDetails = true;
}

hidePerformanceDetails(){
  this.performanceDetails = false;
}
}
